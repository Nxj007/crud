-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 30, 2022 at 09:23 AM
-- Server version: 8.0.28
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--

DROP TABLE IF EXISTS `adminlogin`;
CREATE TABLE IF NOT EXISTS `adminlogin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `adminname` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `utype` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`id`, `adminname`, `password`, `utype`) VALUES
(1, 'admin', 'admin', ''),
(2, 'admin2', 'admin2', ''),
(3, 'Nixk', 'Nixk\r\n', ''),
(5, '\r\nJack', 'Jack', 'Admin'),
(6, 'Nixk', 'Nixk', 'user'),
(7, 'Kaly', 'Kaly', 'User');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
CREATE TABLE IF NOT EXISTS `employees` (
  `eid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `det` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `salary` int NOT NULL,
  `age` int NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `utype` varchar(25) NOT NULL,
  PRIMARY KEY (`eid`) USING BTREE,
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=461 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`eid`, `name`, `email`, `password`, `det`, `salary`, `age`, `image`, `utype`) VALUES
(369, 'Nixk', 'nixkj@ee.i', 'nixk', 'Nixk', 11000, 12, '', 'User'),
(453, 'jack', 'jack@www.in', 'Jack', 'Jack', 11000, 16, '1c5e3328fc5cb834f1479cfd969e04b5.jpg', 'Admin'),
(457, 'kal', 'kal@jj.in', 'Kal', 'Kal', 6000, 13, '9cfc62b375064cfcaac87089174c537b.jpg', 'User'),
(458, 'pat', 'pat', 'pat', 'pat', 5000, 10, '2ecb13ef55a489cfb700d1ec7cf4d39b.png', 'User'),
(460, 'Pratha', 'Pratah@jj.on', 'Pratha', 'Pratha', 11000, 14, '35c13353b3bf7b47e21e8f32d57a0ecbjpeg', 'User');

-- --------------------------------------------------------

--
-- Table structure for table `e_gender`
--

DROP TABLE IF EXISTS `e_gender`;
CREATE TABLE IF NOT EXISTS `e_gender` (
  `eid` int NOT NULL,
  `gid` int NOT NULL,
  KEY `id1` (`eid`),
  KEY `id2` (`gid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `e_gender`
--

INSERT INTO `e_gender` (`eid`, `gid`) VALUES
(369, 1),
(453, 1),
(457, 2),
(458, 1),
(460, 1);

-- --------------------------------------------------------

--
-- Table structure for table `e_hob`
--

DROP TABLE IF EXISTS `e_hob`;
CREATE TABLE IF NOT EXISTS `e_hob` (
  `eid` int NOT NULL,
  `hid` int NOT NULL,
  KEY `id3` (`eid`),
  KEY `id4` (`hid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `e_hob`
--

INSERT INTO `e_hob` (`eid`, `hid`) VALUES
(369, 3),
(369, 4),
(453, 1),
(453, 3),
(453, 4),
(457, 1),
(457, 2),
(457, 3),
(458, 1),
(458, 2),
(458, 3),
(460, 1),
(460, 3);

-- --------------------------------------------------------

--
-- Table structure for table `e_qa`
--

DROP TABLE IF EXISTS `e_qa`;
CREATE TABLE IF NOT EXISTS `e_qa` (
  `eid` int NOT NULL,
  `qid` int NOT NULL,
  KEY `id5` (`eid`),
  KEY `id6` (`qid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `e_qa`
--

INSERT INTO `e_qa` (`eid`, `qid`) VALUES
(369, 3),
(369, 1),
(453, 3),
(457, 1),
(457, 2),
(458, 1),
(458, 2),
(460, 1),
(460, 3);

-- --------------------------------------------------------

--
-- Stand-in structure for view `full_emp`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `full_emp`;
CREATE TABLE IF NOT EXISTS `full_emp` (
`age` int
,`det` varchar(50)
,`eid` int
,`email` varchar(25)
,`h_nm` varchar(25)
,`image` varchar(255)
,`name` varchar(20)
,`password` varchar(20)
,`q_nm` varchar(25)
,`salary` int
,`sx` varchar(10)
,`utype` varchar(25)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `gender_view`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `gender_view`;
CREATE TABLE IF NOT EXISTS `gender_view` (
`eid` int
,`gid` int
,`sx` varchar(10)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `hobby_view`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `hobby_view`;
CREATE TABLE IF NOT EXISTS `hobby_view` (
`eid` int
,`h_nm` varchar(25)
,`hid` int
);

-- --------------------------------------------------------

--
-- Table structure for table `imag`
--

DROP TABLE IF EXISTS `imag`;
CREATE TABLE IF NOT EXISTS `imag` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ImagesTitle` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Image` varchar(150) NOT NULL,
  `PostingDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `imag`
--

INSERT INTO `imag` (`id`, `ImagesTitle`, `Image`, `PostingDate`) VALUES
(1, 'asd', '1c5e3328fc5cb834f1479cfd969e04b5.jpg', '2022-03-16 13:08:14'),
(5, 'a', 'ac7456441f3616fdf2cac07533544a20.jpg', '2022-03-21 14:52:29'),
(6, 'pratha', '270ee74b40f629ca6e9cfb84a1d07b43.jpg', '2022-03-21 14:56:27');

-- --------------------------------------------------------

--
-- Table structure for table `master_gender`
--

DROP TABLE IF EXISTS `master_gender`;
CREATE TABLE IF NOT EXISTS `master_gender` (
  `gid` int NOT NULL,
  `sx` varchar(10) NOT NULL,
  PRIMARY KEY (`gid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `master_gender`
--

INSERT INTO `master_gender` (`gid`, `sx`) VALUES
(1, 'Male'),
(2, 'Female');

-- --------------------------------------------------------

--
-- Table structure for table `master_hobby`
--

DROP TABLE IF EXISTS `master_hobby`;
CREATE TABLE IF NOT EXISTS `master_hobby` (
  `hid` int NOT NULL,
  `h_nm` varchar(25) NOT NULL,
  PRIMARY KEY (`hid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `master_hobby`
--

INSERT INTO `master_hobby` (`hid`, `h_nm`) VALUES
(1, 'cricket'),
(2, 'dancing'),
(3, 'football'),
(4, 'reading');

-- --------------------------------------------------------

--
-- Table structure for table `master_qa`
--

DROP TABLE IF EXISTS `master_qa`;
CREATE TABLE IF NOT EXISTS `master_qa` (
  `qid` int NOT NULL AUTO_INCREMENT,
  `q_nm` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`qid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `master_qa`
--

INSERT INTO `master_qa` (`qid`, `q_nm`) VALUES
(1, 'ME'),
(2, 'BE'),
(3, 'BSc'),
(4, 'MSc');

-- --------------------------------------------------------

--
-- Stand-in structure for view `qa_view`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `qa_view`;
CREATE TABLE IF NOT EXISTS `qa_view` (
`eid` int
,`q_nm` varchar(25)
,`qid` int
);

-- --------------------------------------------------------

--
-- Table structure for table `tblimages`
--

DROP TABLE IF EXISTS `tblimages`;
CREATE TABLE IF NOT EXISTS `tblimages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ImagesTitle` varchar(120) DEFAULT NULL,
  `Image` varchar(150) DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `utype` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `dt`, `utype`) VALUES
(1, 'admin', 'admin', '2022-03-16 16:23:22', ''),
(2, 'kal', 'kal', '2022-03-22 11:58:02', '');

-- --------------------------------------------------------

--
-- Structure for view `full_emp`
--
DROP TABLE IF EXISTS `full_emp`;

DROP VIEW IF EXISTS `full_emp`;
CREATE VIEW `full_emp`  AS SELECT `emp`.`eid` AS `eid`, `emp`.`name` AS `name`, `emp`.`email` AS `email`, `emp`.`password` AS `password`, `emp`.`det` AS `det`, `gv`.`sx` AS `sx`, `hv`.`h_nm` AS `h_nm`, `qv`.`q_nm` AS `q_nm`, `emp`.`salary` AS `salary`, `emp`.`age` AS `age`, `emp`.`image` AS `image`, `emp`.`utype` AS `utype` FROM (((`employees` `emp` join `gender_view` `gv` on((`emp`.`eid` = `gv`.`eid`))) join `hobby_view` `hv` on((`emp`.`eid` = `hv`.`eid`))) join `qa_view` `qv` on((`emp`.`eid` = `qv`.`eid`))) ORDER BY `emp`.`eid` ASC ;

-- --------------------------------------------------------

--
-- Structure for view `gender_view`
--
DROP TABLE IF EXISTS `gender_view`;

DROP VIEW IF EXISTS `gender_view`;
CREATE VIEW `gender_view`  AS SELECT `emp`.`eid` AS `eid`, `mg`.`gid` AS `gid`, `mg`.`sx` AS `sx` FROM ((`employees` `emp` join `e_gender` `eg` on((`emp`.`eid` = `eg`.`eid`))) join `master_gender` `mg` on((`eg`.`gid` = `mg`.`gid`))) ;

-- --------------------------------------------------------

--
-- Structure for view `hobby_view`
--
DROP TABLE IF EXISTS `hobby_view`;

DROP VIEW IF EXISTS `hobby_view`;
CREATE VIEW `hobby_view`  AS SELECT `e_hob`.`eid` AS `eid`, `e_hob`.`hid` AS `hid`, `master_hobby`.`h_nm` AS `h_nm` FROM (`e_hob` join `master_hobby` on((`e_hob`.`hid` = `master_hobby`.`hid`))) ;

-- --------------------------------------------------------

--
-- Structure for view `qa_view`
--
DROP TABLE IF EXISTS `qa_view`;

DROP VIEW IF EXISTS `qa_view`;
CREATE VIEW `qa_view`  AS SELECT `emp`.`eid` AS `eid`, `mqa`.`qid` AS `qid`, `mqa`.`q_nm` AS `q_nm` FROM ((`e_qa` `qa` join `employees` `emp` on((`emp`.`eid` = `qa`.`eid`))) join `master_qa` `mqa` on((`mqa`.`qid` = `qa`.`qid`))) ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `e_gender`
--
ALTER TABLE `e_gender`
  ADD CONSTRAINT `id1` FOREIGN KEY (`eid`) REFERENCES `employees` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id2` FOREIGN KEY (`gid`) REFERENCES `master_gender` (`gid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `e_hob`
--
ALTER TABLE `e_hob`
  ADD CONSTRAINT `id3` FOREIGN KEY (`eid`) REFERENCES `employees` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id4` FOREIGN KEY (`hid`) REFERENCES `master_hobby` (`hid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `e_qa`
--
ALTER TABLE `e_qa`
  ADD CONSTRAINT `id5` FOREIGN KEY (`eid`) REFERENCES `employees` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id6` FOREIGN KEY (`qid`) REFERENCES `master_qa` (`qid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
