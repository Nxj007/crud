How to run this script 

Download the zip
Extract zip file and put in the root directory
open phpmyadmin. 
http://localhost/phpmyadmin

Create a db imagesdata then import SQL file(given inside the package)