-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 17, 2022 at 07:39 AM
-- Server version: 8.0.28
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crud`
--
CREATE DATABASE IF NOT EXISTS `crud` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE `crud`;

-- --------------------------------------------------------

--
-- Table structure for table `adminlogin`
--
-- Creation: Mar 15, 2022 at 12:32 PM
--

DROP TABLE IF EXISTS `adminlogin`;
CREATE TABLE IF NOT EXISTS `adminlogin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `adminname` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `adminlogin`
--

INSERT INTO `adminlogin` (`id`, `adminname`, `password`) VALUES
(1, 'admin', 'admin'),
(2, 'admin2', 'admin2'),
(3, 'Nixk', 'Nixk\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--
-- Creation: Mar 17, 2022 at 07:19 AM
--

DROP TABLE IF EXISTS `employees`;
CREATE TABLE IF NOT EXISTS `employees` (
  `eid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `email` varchar(25) NOT NULL,
  `password` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `det` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `salary` int NOT NULL,
  `age` int NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `utype` varchar(25) NOT NULL,
  PRIMARY KEY (`eid`) USING BTREE,
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=370 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`eid`, `name`, `email`, `password`, `det`, `salary`, `age`, `image`, `utype`) VALUES
(369, 'Nixk', 'nixkj@ee.i', 'nixk', 'Nixk', 11000, 12, '', 'User');

-- --------------------------------------------------------

--
-- Table structure for table `e_gender`
--
-- Creation: Mar 14, 2022 at 11:39 AM
-- Last update: Mar 17, 2022 at 07:16 AM
--

DROP TABLE IF EXISTS `e_gender`;
CREATE TABLE IF NOT EXISTS `e_gender` (
  `eid` int NOT NULL,
  `gid` int NOT NULL,
  KEY `id1` (`eid`),
  KEY `id2` (`gid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `e_gender`
--

INSERT INTO `e_gender` (`eid`, `gid`) VALUES
(369, 1),
(369, 1);

-- --------------------------------------------------------

--
-- Table structure for table `e_hob`
--
-- Creation: Mar 15, 2022 at 09:42 AM
--

DROP TABLE IF EXISTS `e_hob`;
CREATE TABLE IF NOT EXISTS `e_hob` (
  `eid` int NOT NULL,
  `hid` int NOT NULL,
  KEY `id3` (`eid`),
  KEY `id4` (`hid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Table structure for table `e_qa`
--
-- Creation: Mar 15, 2022 at 07:46 AM
-- Last update: Mar 16, 2022 at 06:05 AM
--

DROP TABLE IF EXISTS `e_qa`;
CREATE TABLE IF NOT EXISTS `e_qa` (
  `eid` int NOT NULL,
  `qid` int NOT NULL,
  KEY `id5` (`eid`),
  KEY `id6` (`qid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Stand-in structure for view `gender_view`
-- (See below for the actual view)
--
DROP VIEW IF EXISTS `gender_view`;
CREATE TABLE IF NOT EXISTS `gender_view` (
`eid` int
,`sx` varchar(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `imag`
--
-- Creation: Mar 16, 2022 at 07:36 AM
--

DROP TABLE IF EXISTS `imag`;
CREATE TABLE IF NOT EXISTS `imag` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ImagesTitle` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Image` varchar(150) NOT NULL,
  `PostingDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `imag`
--

INSERT INTO `imag` (`id`, `ImagesTitle`, `Image`, `PostingDate`) VALUES
(1, 'asd', '1c5e3328fc5cb834f1479cfd969e04b5.jpg', '2022-03-16 13:08:14'),
(3, 'Moh _Ali', '270ee74b40f629ca6e9cfb84a1d07b43.jpg', '2022-03-16 13:09:40'),
(4, 'Moh _Ali', '270ee74b40f629ca6e9cfb84a1d07b43.jpg', '2022-03-16 13:15:22');

-- --------------------------------------------------------

--
-- Table structure for table `master_gender`
--
-- Creation: Mar 14, 2022 at 11:34 AM
--

DROP TABLE IF EXISTS `master_gender`;
CREATE TABLE IF NOT EXISTS `master_gender` (
  `gid` int NOT NULL,
  `sx` varchar(10) NOT NULL,
  PRIMARY KEY (`gid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `master_gender`
--

INSERT INTO `master_gender` (`gid`, `sx`) VALUES
(1, 'Male'),
(2, 'Female');

-- --------------------------------------------------------

--
-- Table structure for table `master_hobby`
--
-- Creation: Mar 14, 2022 at 11:35 AM
--

DROP TABLE IF EXISTS `master_hobby`;
CREATE TABLE IF NOT EXISTS `master_hobby` (
  `hid` int NOT NULL,
  `h_nm` varchar(25) NOT NULL,
  PRIMARY KEY (`hid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `master_hobby`
--

INSERT INTO `master_hobby` (`hid`, `h_nm`) VALUES
(1, 'cricket'),
(2, 'dancing'),
(3, 'football'),
(4, 'reading');

-- --------------------------------------------------------

--
-- Table structure for table `master_qa`
--
-- Creation: Mar 15, 2022 at 05:51 AM
--

DROP TABLE IF EXISTS `master_qa`;
CREATE TABLE IF NOT EXISTS `master_qa` (
  `qid` int NOT NULL AUTO_INCREMENT,
  `q_nm` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`qid`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `master_qa`
--

INSERT INTO `master_qa` (`qid`, `q_nm`) VALUES
(1, 'ME'),
(2, 'BE'),
(3, 'BSc'),
(4, 'MSc');

-- --------------------------------------------------------

--
-- Table structure for table `tblimages`
--
-- Creation: Mar 16, 2022 at 07:34 AM
--

DROP TABLE IF EXISTS `tblimages`;
CREATE TABLE IF NOT EXISTS `tblimages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ImagesTitle` varchar(120) DEFAULT NULL,
  `Image` varchar(150) DEFAULT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--
-- Creation: Mar 16, 2022 at 10:52 AM
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `dt` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `dt`) VALUES
(1, 'admin', 'admin', '2022-03-16 16:23:22');

-- --------------------------------------------------------

--
-- Structure for view `gender_view`
--
DROP TABLE IF EXISTS `gender_view`;
-- Creation: Mar 16, 2022 at 10:15 AM
--

DROP VIEW IF EXISTS `gender_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `gender_view`  AS SELECT `eg`.`eid` AS `eid`, `mg`.`sx` AS `sx` FROM (`e_gender` `eg` join `master_gender` `mg` on((`eg`.`gid` = `mg`.`gid`))) ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `e_gender`
--
ALTER TABLE `e_gender`
  ADD CONSTRAINT `id1` FOREIGN KEY (`eid`) REFERENCES `employees` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id2` FOREIGN KEY (`gid`) REFERENCES `master_gender` (`gid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `e_hob`
--
ALTER TABLE `e_hob`
  ADD CONSTRAINT `id3` FOREIGN KEY (`eid`) REFERENCES `employees` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id4` FOREIGN KEY (`hid`) REFERENCES `master_hobby` (`hid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `e_qa`
--
ALTER TABLE `e_qa`
  ADD CONSTRAINT `id5` FOREIGN KEY (`eid`) REFERENCES `employees` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `id6` FOREIGN KEY (`qid`) REFERENCES `master_qa` (`qid`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
